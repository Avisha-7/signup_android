package com.example.form_arudito;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
