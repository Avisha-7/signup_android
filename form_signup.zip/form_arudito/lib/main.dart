import 'package:flutter/material.dart';
import 'package:ui_tut/const.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SignUpPage(),
    );
  }
}

class SignUpPage extends StatefulWidget {
  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  String name, email, password, phoneNumber;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  Widget _buildLogo() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 70),
          child: Text(
            'SIGN UP',
            style: TextStyle(
              fontSize: MediaQuery.of(context).size.height / 25,
//              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        )
      ],
    );
  }
  Widget _buildNameRow() {
    return Padding(
      padding: EdgeInsets.all(8),
      child: TextFormField(
        keyboardType: TextInputType.text,
//        onChanged: (value) {
//          setState(() {
//            name = value;
//          });
//        },
        decoration: InputDecoration(
            prefixIcon: Icon(
              Icons.account_circle,
              color: mainColor,
            ),
            labelText: 'Name'),
        validator: (String value){
          if(value.isEmpty){
            return 'Name is Required';
          }
          return null;
        },
        onSaved: (String value) {
          name = value;
        },
      ),
    );
  }

  Widget _buildEmailRow() {
    return Padding(
      padding: EdgeInsets.all(8),
      child: TextFormField(
        keyboardType: TextInputType.emailAddress,
//        onChanged: (value) {
//          setState(() {
//            email = value;
//          });
//        },
        decoration: InputDecoration(
            prefixIcon: Icon(
              Icons.email,
              color: mainColor,
            ),
            labelText: 'E-mail'),
        validator: (String value){
          if(value.isEmpty){
            return 'Email Address is Required';
          }
          if(!RegExp(r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,253}[a-zA-Z0-9])?)*$").hasMatch(value)){
            return 'Please enter a valid email address';
          }
          return null;

        },
        onSaved: (String value) {
          email = value;
        },
      ),
    );
  }

  Widget _buildPhoneNumberRow() {
    return Padding(
      padding: EdgeInsets.all(8),
      child: TextFormField(
        keyboardType: TextInputType.phone,
        onChanged: (value) {
          setState(() {
            phoneNumber = value;
          });
        },
        decoration: InputDecoration(
            prefixIcon: Icon(
              Icons.local_phone,
              color: mainColor,
            ),
            labelText: 'Phone Number'),
        validator: (String value){
          if(value.isEmpty){
            return 'Phone Number is Required';
          }
          return null;
        },
        onSaved: (String value) {
          phoneNumber = value;
        },

      ),
    );
  }

  Widget _buildPasswordRow() {
    return Padding(
      padding: EdgeInsets.all(8),
      child: TextFormField(
        keyboardType: TextInputType.text,
        obscureText: true,
//        onChanged: (value) {
//          setState(() {
//            password = value;
//          });
//        },
        decoration: InputDecoration(
          prefixIcon: Icon(
            Icons.lock,
            color: mainColor,
          ),
          labelText: 'Password',
        ),
        validator: (String value){
          if(value.isEmpty){
            return 'Password is Required';
          }
          return null;
        },
        onSaved: (String value) {
          password = value;
        },
      ),
    );
  }

  Widget _buildSignUpButton() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Container(
          height: 1.2* (MediaQuery.of(context).size.height / 20),
          width: 4 * (MediaQuery.of(context).size.width / 10),
//          margin: EdgeInsets.only(bottom: 20),
          margin: EdgeInsets.only(top: 30),
          child: RaisedButton(
            elevation: 6.0,
            color: mainColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(7.0),
            ),

            onPressed: () {
              if(!_formKey.currentState.validate()){
                return;
              }
              _formKey.currentState.save();
              print(name);
              print(email);
              print(phoneNumber);
            },
            child: Text(
              "Register",
              style: TextStyle(
                color: Colors.white,
                letterSpacing: 1.5,
                fontSize: MediaQuery.of(context).size.height / 40,
              ),
            ),
          ),
        )
      ],
    );
  }

  Widget _buildContainer() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        ClipRRect(
          borderRadius: BorderRadius.all(
            Radius.circular(20),
          ),
          child: FadeAnimation(1,Container(
            height: MediaQuery.of(context).size.height * 0.625,
            width: MediaQuery.of(context).size.width * 0.82,
            decoration: BoxDecoration(
              color: Colors.white,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                ),
                _buildNameRow(),
                _buildEmailRow(),
                _buildPhoneNumberRow(),
                _buildPasswordRow(),
                _buildSignUpButton(),
              ],
            ),
          )),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomPadding: false,
        backgroundColor: Color(0xfff2f3f7),
        body: Stack(
          children: <Widget>[
            Container(
              height: MediaQuery.of(context).size.height * 0.7,
              width: MediaQuery.of(context).size.width,
              child: Container(
                decoration: BoxDecoration(
                  color: mainColor,
                  borderRadius: BorderRadius.only(
                    bottomLeft: const Radius.circular(70),
                    bottomRight: const Radius.circular(70),
                  ),
                ),
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                _buildLogo(),
                _buildContainer(),
              ],
            )
          ],
        ),
      ),
    );
  }
}

